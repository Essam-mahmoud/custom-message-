//
//  ViewController.swift
//  customMessage
//
//  Created by Essam Mahmoud fathy on 11/5/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class CustomMessage: UIViewController {

    @IBOutlet weak var BigView: UIView!{
        didSet{
            BigView.layer.cornerRadius = 10
            BigView.layer.borderColor = UIColor.yellow.cgColor
            BigView.layer.borderWidth = 2
        }
    }
    @IBOutlet weak var Button: UIButton!{
        didSet{
            Button.layer.cornerRadius = 10
        }
    }
    @IBOutlet weak var Lable: UILabel!
    var Message : String!
    override func viewDidLoad() {
        super.viewDidLoad()
        Lable.text = Message
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func OkAction(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    

}




class MessageBox{
    static func show(Message : String, MyVC : UIViewController){
        let Storybord = UIStoryboard.init(name: "customMessage", bundle: nil)
        let VC = Storybord.instantiateViewController(withIdentifier: "message") as! CustomMessage
        VC.modalPresentationStyle = .overFullScreen
        VC.modalTransitionStyle = .crossDissolve
        VC.Message = Message
        MyVC.present(VC, animated: true, completion: nil)
        

    }
}

